nkf -w -Lu AddPersonStatus.java > tmp
cp tmp AddPersonStatus.java
nkf -w -Lu AddWorkStatus.java > tmp
cp tmp AddWorkStatus.java
nkf -w -Lu client.csv > tmp
cp tmp client.csv
nkf -w -Lu Client.java > tmp
cp tmp Client.java
nkf -w -Lu ClientList.java > tmp
cp tmp ClientList.java
nkf -w -Lu ConsoleStatus.java > tmp
cp tmp ConsoleStatus.java
nkf -w -Lu DeletePersonStatus.java > tmp
cp tmp DeletePersonStatus.java
nkf -w -Lu DeleteWorkStatus.java > tmp
cp tmp DeleteWorkStatus.java
nkf -w -Lu DisplayPersonsByNameStatus.java > tmp
cp tmp DisplayPersonsByNameStatus.java
nkf -w -Lu DisplayPersonsByTypeStatus.java > tmp
cp tmp DisplayPersonsByTypeStatus.java
nkf -w -Lu DisplayPersonStatus.java > tmp
cp tmp DisplayPersonStatus.java
nkf -w -Lu ExitStatus.java > tmp
cp tmp ExitStatus.java
nkf -w -Lu FileLoader.java > tmp
cp tmp FileLoader.java
nkf -w -Lu FileSaver.java > tmp
cp tmp FileSaver.java
nkf -w -Lu NameSelectionStatus.java > tmp
cp tmp NameSelectionStatus.java
nkf -w -Lu person.csv > tmp
cp tmp person.csv
nkf -w -Lu Person.java > tmp
cp tmp Person.java
nkf -w -Lu PersonList.java > tmp
cp tmp PersonList.java
nkf -w -Lu Record.java > tmp
cp tmp Record.java
nkf -w -Lu RecordList.java > tmp
cp tmp RecordList.java
nkf -w -Lu SystemManager.java > tmp
cp tmp SystemManager.java
nkf -w -Lu TypeSelectionStatus.java > tmp
cp tmp TypeSelectionStatus.java
nkf -w -Lu UpdatePersonStatus.java > tmp
cp tmp UpdatePersonStatus.java
nkf -w -Lu work.csv > tmp
cp tmp work.csv
nkf -w -Lu Work.java > tmp
cp tmp Work.java
nkf -w -Lu WorkList.java > tmp
cp tmp WorkList.java
